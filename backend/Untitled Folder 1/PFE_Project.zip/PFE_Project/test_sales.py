# test_sales.py
from bedrock_client import ask_sales_total

# Test California sales
print("\n🔍 Testing California sales total...")
print("="*60)
result = ask_sales_total("california")
print(result)
print("="*60)